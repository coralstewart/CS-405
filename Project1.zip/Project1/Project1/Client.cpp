#include <iostream>
#include <string>

using namespace std;

// i pulled these names from the strings in Codio
string name1 = "Bob Jones";
string name2 = "Sarah Davis";
string name3 = "Amy Friendly";
string name4 = "Johnny Smith";
string name5 = "Carol Spears";

//giving num values for the displayinfo block 
int num1 = 1;
int num2 = 2;
int num3 = 1;
int num4 = 1;
int num5 = 2;

string username;
string password;
int answer = 0;

//declare functions
int CheckUserPermissionAccess();
void ChangeCustomerChoice();
void DisplayInfo();

int main() {
    //the requested statement from assignment guidelines
    cout << "Created by Coral Stewart" << endl;
    cout << "Hello! Welcome to our Investment Company" << endl;

    cout << "Enter your username: ";
    cin >> username;

    cout << "Enter your password: ";
    cin >> password;

    int access = CheckUserPermissionAccess();

    if (access == 1) {
        cout << "Invalid Password. Please try again" << endl;
        cout << "Enter your username: ";
        cin >> username;
        cout << "Enter your password: ";
        cin >> password;
        access = CheckUserPermissionAccess();
    }

    if (access == 1) {
        cout << "Invalid Password. Please try again" << endl;
        return 0;
    }

    //display menu options
    do {
        cout << "What would you like to do?" << endl;
        cout << "DISPLAY the client list (enter 1)" << endl;
        cout << "CHANGE a client's choice (enter 2)" << endl;
        cout << "Exit the program.. (enter 3)" << endl;
        cout << "You chose ";
        cin >> answer;

        if (answer == 1) {
            DisplayInfo();
        }
        else if (answer == 2) {
            ChangeCustomerChoice();
        }
    } while (answer != 3);

    return 0;
}

int CheckUserPermissionAccess() {
    //USE THIS USER AND PASS 
    if (username == "admin" && password == "pass123") {
        //if authorized:
        return 2; 
    }
    else {
        //if unauthorized:
        return 1;
    }
}

void ChangeCustomerChoice() {
    int clientNumber, newService;

    cout << "Enter the number of the client that you wish to change" << endl;
    cin >> clientNumber;

    cout << "Please enter the client's new service choice (1 = Brokerage, 2 = Retirement)" << endl;
    cin >> newService;

    switch (clientNumber) {
    case 1:
        num1 = newService;
        break;
    case 2:
        num2 = newService;
        break;
    case 3:
        num3 = newService;
        break;
    case 4:
        num4 = newService;
        break;
    case 5:
        num5 = newService;
        break;
    default:
        break;
    }
}

void DisplayInfo() {
    cout << "  Client's Name    Service Selected (1 = Brokerage, 2 = Retirement)" << endl;
    cout << name1 << "     " << num1 << endl;
    cout << name2 << "     " << num2 << endl;
    cout << name3 << "     " << num3 << endl;
    cout << name4 << "     " << num4 << endl;
    cout << name5 << "     " << num5 << endl;
}
